/*
 *	MCreator note:
 *
 *	If you lock base mod element files, you can edit this file and the proxy files
 *	and they won't get overwritten. If you change your mod package or modid, you
 *	need to apply these changes to this file MANUALLY.
 *
 *
 *	If you do not lock base mod element files in Workspace settings, this file
 *	will be REGENERATED on each build.
 *
 */
package net.mcreator.starfields;

import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.LogManager;
import net.fabricmc.loader.api.FabricLoader;
import net.fabricmc.api.ModInitializer;

import net.mcreator.starfields.init.StarfieldsModItems;


public class StarfieldsMod implements ModInitializer {
	public static final Logger LOGGER = LogManager.getLogger();
	public static final boolean IS_TRINKETS_LOADED = FabricLoader.getInstance().getModContainer("trinkets").isPresent();
	public static final String MODID = "starfields";

	@Override
	public void onInitialize() {
		LOGGER.info("Initializing StarfieldsMod");



		StarfieldsModItems.load();

	}
}
