/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.starfields.init;

import net.minecraft.world.item.Item;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.Registry;

import net.mcreator.starfields.item.RareplushieItem;
import net.mcreator.starfields.item.PlushieItem;
import net.mcreator.starfields.StarfieldsMod;

public class StarfieldsModItems {
	public static Item RARE_PLUSHIE;
	public static Item PLUSHIE;

	public static void load() {
		RARE_PLUSHIE = Registry.register(BuiltInRegistries.ITEM, new ResourceLocation(StarfieldsMod.MODID, "rare_plushie"), new RareplushieItem());
		PLUSHIE = Registry.register(BuiltInRegistries.ITEM, new ResourceLocation(StarfieldsMod.MODID, "plushie"), new PlushieItem());
	}

	public static void clientLoad() {
	}
}
