package net.mcreator.starfields.compat.trinkets;

import dev.emi.trinkets.api.client.TrinketRendererRegistry;

import net.mcreator.starfields.item.PlushieItem;
import net.mcreator.starfields.item.RareplushieItem;

public class TrinketsIntegration {


        public static void registerTrinkets() {
            TrinketRendererRegistry.registerRenderer((PlushieItem).asItem(), new TrinketsClientRenderer());
            TrinketRendererRegistry.registerRenderer((RareplushieItem).asItem(), new TrinketsClientRenderer());
        }
    }

